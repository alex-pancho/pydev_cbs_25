print("Hello, World. Let's play!")
print('Hello, World!')
long_string = """Тут ми можемо писти все,
що нам завгодно і дуже
дуже довгі тексти також
"""
print(long_string)
long_string = "Asdf"
print(long_string)
# long_string = 1   # можна присвоїти любе значення, але так робити не варто
# print(long_string) 
current_year = 2025
print(current_year)
print(current_year, long_string)
name = "Jklp"
print(long_string + name)
pre_year = current_year - 1
print(pre_year)

apples = 10
oranges = 5
total_fruit = oranges + apples
print(f"I have {apples} apples")
print(f"I have {oranges} oranges")
# print("Totaly I have:", total_fruit, "fruits") # Рівноцінно до стр. 27
# Here is out for total fruits
print(f"Totaly I have: {total_fruit} fruits")

print(102983091284098 - 71284828)
print(7 ** 9)
print(96 / 2)
print("Визначити тип змінної:")
print(type(current_year))
print(type(long_string))

text = input("Enter some text: ")
print(text)
